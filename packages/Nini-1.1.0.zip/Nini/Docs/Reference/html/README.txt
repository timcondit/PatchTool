------------------
HTML DOCUMENTATION
------------------

This directory is where all NDoc (http://ndoc.sourceforge.net/) generated 
HTML files are located.  These files are only viewable with any recent 
web browser (Firefox, IE, Opera).  

If you would like to help write this documentation 
for the Nini project then please these look at the following file:
Nini\Docs\Reference\xml\README.txt

Download the excellent Mozilla Firefox browser:
http://www.mozilla.org/

