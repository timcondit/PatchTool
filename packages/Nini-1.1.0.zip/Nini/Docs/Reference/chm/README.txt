This directory is where all Microsoft Windows HTML Help (*.chm) 
files are located.  These are only viewable on Microsoft Windows 
operating systems with Internet Explorer 4.0 or higher.  The CHM files
were created with NDoc combined with the MS HTML Help Workshop.

If you would like to help write this documentation 
for the Nini project then please these look at the following file:
Nini\Docs\Reference\xml\README.txt

Home page for the Microsoft HTML Help Workshop:

http://msdn.microsoft.com/library/default.asp?url=/library/en-us/htmlhelp/html/vsconHH1Start.asp

If you are using a UNIX operating system and you would like to be able to 
read CHM files then there is an excellent utility called xCHM for Linux, 
BSD, Solaris, and Mac OS X.  You can download it here:

http://xchm.sourceforge.net/
